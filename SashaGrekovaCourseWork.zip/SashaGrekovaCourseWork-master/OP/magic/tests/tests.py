import unittest


class magicSqrTest(unittest.TestCase):
    def setUp(self):
        pass

    def test_magicSqrTest1(self):
        result = magicSQR("0")
        self.assertEqual('Error, incorrect input', result)

    def test_magicSqrTest2(self):
        result = magicSQR("5")
        listing=[17, 24, 1, 8, 15, 23, 5, 7, 14, 16, 4, 6, 13, 20, 22, 10, 12, 19, 21, 3, 11, 18, 25, 2, 9]
        self.assertEqual(listing, result)

    def test_magicSqrTest3(self):
        result = magicSQR("3")
        listing = [8, 1, 6, 3, 5, 7, 4, 9, 2]
        self.assertEqual(listing, result)

    def test_magicSqrTest4(self):
        test = [129, 147, 165, 183, 201, 219, 237, 255, 1, 19, 37,
                55, 73, 91, 109, 127, 146, 164, 182, 200, 218, 236, 254, 16,
                18, 36, 54, 72, 90, 108, 126, 144, 163, 181, 199, 217, 235, 253,
                15, 17, 35, 53, 71, 89, 107, 125, 143, 145, 180, 198, 216, 234, 252,
                14, 32, 34, 52, 70, 88, 106, 124, 142, 160, 162, 197, 215, 233, 251, 13, 31,
                33, 51, 69, 87, 105, 123, 141, 159, 161, 179, 214, 232, 250, 12, 30,
                48, 50, 68, 86, 104, 122, 140, 158, 176, 178, 196, 231, 249, 11, 29, 47,
                49, 67, 85, 103, 121, 139, 157, 175, 177, 195, 213, 248, 10, 28, 46, 64, 66,
                84, 102, 120, 138, 156, 174, 192, 194, 212, 230, 9, 27, 45, 63, 65, 83, 101, 119,
                137, 155, 173, 191, 193, 211, 229, 247, 26, 44, 62, 80, 82, 100, 118, 136, 154, 172,
                190, 208, 210, 228, 246, 8, 43, 61, 79, 81, 99, 117, 135, 153, 171, 189, 207, 209, 227,
                245, 7, 25, 60, 78, 96, 98, 116, 134, 152, 170, 188, 206, 224, 226, 244, 6, 24, 42, 77,
                95, 97, 115, 133, 151, 169, 187, 205, 223, 225, 243, 5, 23, 41, 59, 94, 112, 114, 132, 150,
                168, 186, 204, 222, 240, 242, 4, 22, 40, 58, 76, 111, 113, 131, 149, 167, 185, 203, 221, 239,
                241, 3, 21, 39, 57, 75, 93, 128, 130, 148, 166, 184, 202,
                220, 238, 256, 2, 20, 38, 56, 74, 92, 110]
        result = magicSQR("16")
        self.assertEqual(test, result)

    def test_magicSqrTest5(self):
        result = magicSQR("2.5")
        self.assertEqual('Error, incorrect input', result)

    def test_magicSqrTest6(self):
        result = magicSQR("клякса")
        self.assertEqual('Error, incorrect input', result)

def magicSQR(number):
  if number.isdigit() and number!="0":
    N = int(number)
    length = N * N
    mx = [[None for z in range(N)] for z in range(N)]
    y = 0
    x = N // 2
    mx[y][x] = 1
    for i in range(2, length + 1):
      old_x, old_y = x, y
      x = (x + 1) % N
      y = (y - 1) % N
      if not mx[y][x] is None:
        x = old_x
        y = (old_y + 1) % N
      mx[y][x] = i
    a = []
    for y in mx:
      a += y
    ans = a
    return ans

  else:
    ans = "Error, incorrect input"
    return ans