from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.db.utils import IntegrityError
from .models import User
from .forms import FormForFile
from django.utils.datastructures import MultiValueDictKeyError
from django.contrib import messages
from django.core.files import File
import os
from PIL import Image
from PIL import ImageDraw

def reg(request):
    return render(request, 'signin.html')

def Form(request):
    return render(request, 'Form.html')

def SignUp(request):
    try:
        if request.method == "POST":
            user = User()
            username = request.POST.get("Username")
            password = request.POST.get("Password")
            if len(username) > 4 or len(password) > 4:
                user.Login = request.POST.get("Username")
                user.Password = request.POST.get("Password")
                user.save()
                return HttpResponseRedirect("http://127.0.0.1:8000/form")
            else:
                data = {
                    'Username': username,
                    'Password': password,
                }
                messages.error(request, 'Login or Password must be over 4')
                return render(request, "signin.html", data)
    except IntegrityError:
        data = {
            'Username': username,
            'Password': password,
        }
        messages.error(request, 'Choose another Login. This login is busy')
        return render(request, "signin.html", data)

def makePic(request):
    form = FormForFile(request.POST, request.FILES or None)
    if request.method == "POST":
        username = request.POST.get("Username")
        password = request.POST.get("Password")
        number = request.POST.get('number')
        try:
            checkUserLogin = User.objects.get(Login=username, Password=password)
            if checkUserLogin is not None:
                data = {
                    'Username': username,
                    'Password': password,
                    'number': number
                }
                result = magicSQR(number)
                image = Image.new("RGB", (700, 700))
                draw = ImageDraw.Draw(image)
                counter = 0
                check = int(number)
                text = ""
                for i in range(len(result)):
                    text += str(result[0]) + " "
                    del result[0]
                    counter += 1
                    if counter == check:
                        text += " "+"\n"
                        check += int(number)
                draw.text((10, 10), text)
                image.save("Image", "PNG")
                image.show()
                return render(request, "Form.html", data)
        except User.DoesNotExist:
            data = {
                'Username': username,
                'Password': password,
                'number': number
            }
            messages.error(request, "Incorrect Login or Password")
            return render(request, "Form.html", data)

def magicSQR(number):
  if number.isdigit() and number!="0":
    N = int(number)
    length = N * N
    mx = [[None for z in range(N)] for z in range(N)]
    y = 0
    x = N // 2
    mx[y][x] = 1
    for i in range(2, length + 1):
      old_x, old_y = x, y
      x = (x + 1) % N
      y = (y - 1) % N
      if not mx[y][x] is None:
        x = old_x
        y = (old_y + 1) % N
      mx[y][x] = i
    a = []
    for y in mx:
      a += y
    ans = a
    return ans

  else:
    ans = "Error, incorrect input"
    return ans