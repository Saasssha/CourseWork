from . import views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.reg),
    path('form', views.Form),
    path('Registration', views.SignUp),
    path('Calcs', views.makePic)
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)